<?php
require "misc/header.php";

// Feel free to add your donation options here, but please don't remove mine.
?>

<title>LinXer - Donate</title>
<body>
<div class="misc-container">
    <h1>Donate to the <a href="https://github.com/hnhx" target="_blank">LibreX Developer</a></h1>
    <h3>Bitcoin (BTC):</h3>
    <p>bc1qs43kh6tvhch02dtsp7x7hcrwj8fwe4rzy7lp0h</p>
    <h3>Monero (XMR):</h3>
    <p>41dGQr9EwZBfYBY3fibTtJZYfssfRuzJZDSVDeneoVcgckehK3BiLxAV4FvEVJiVqdiW996zvMxhFB8G8ot9nBFqQ84VkuC</p>
</div>

<?php require "misc/footer.php"; ?>
